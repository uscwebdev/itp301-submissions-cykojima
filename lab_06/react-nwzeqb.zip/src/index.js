import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Comment from './comment.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="container">
      <div id="row1">
        <h1>Conner's Surfing Guide</h1>
        <a href="https://www.surfline.com/">Surfing Forecast</a>
        <div id="text_box">
          <p>
            Surfing is a challenging task that challenges both mind and body in
            harnessing the ocean's unbridled force. Surfing is an extreme sport
            with a long history. It was recently introduced as an Olympic Sport.
            In places like Hawaii and Brazil, it is viewed as a popular
            pasttime. Movies like Maverics and Surfs up have covered the sport.
          </p>
        </div>
      </div>
      <h2>Exhibit A: Long Board</h2>
      <img
        src="https://cdn-5ca51fc3f911c91ddc742258.closte.com/wp-content/uploads/surfingtraining2.png"
        alt="image"
      />
      <div id="text_box">
        <p>
          There are two main types of boards that surfers use: short boards and
          long boards. Short boards are around 7 ft and under whereas long
          boards can range from 7 ft to 10 ft! Most beginners will start with a
          long board because it will glide across the water whereas a short
          board requires a significant amount of energy to paddle.{' '}
        </p>
      </div>
      <h2>Exhibit B: Short Board</h2>
      <img
        src="https://cdn.shopify.com/s/files/1/0411/9757/files/Degree-33-Surfboards-shortboards-3306-web_2048x.jpg?2096"
        alt="image"
      />
      <div id="text_box">
        <p>
          More experienced surfers and professionals will most likely use short
          boards. Despite being much more difficult to paddle, short boards by
          virture of their size allow for greater maneuvering and tricks.
          Whereas riding up the ramp up of a wave and gaining air time is nearly
          impossible with a 8ft board, a professional surfery on a ~6ft board
          with good core strength and balance can do aerials on a wave.
        </p>
      </div>
      <h2>Comments Section</h2>
      <Comment
        username="kojiconner"
        date="10/4/2023"
        message="Wow! Surfing is so cool! I’ve always wanted to learn how to do it."
        avatar_src="https://icon2.cleanpng.com/20180216/pww/kisspng-user-male-icon-business-user-cliparts-5a8748cf2ab751.394028601518815439175.jpg"
        avatar_alt="Kojiconner profile picture"
      />
      <Comment
        username="Billy"
        date="10/8/2023"
        message="Charge Large! I'm trying to learn how to shortboard!"
        avatar_src="https://icon2.cleanpng.com/20180216/pww/kisspng-user-male-icon-business-user-cliparts-5a8748cf2ab751.394028601518815439175.jpg"
        avatar_alt="Billy's profile picture"
      />
      <Comment
        username="Jilly"
        date="10/10/2023"
        message="Sheeeesh, theres a swell near OC this weekend. check it out if can,
        bumbeye you might miss out!"
        avatar_src="https://icon2.cleanpng.com/20180216/pww/kisspng-user-male-icon-business-user-cliparts-5a8748cf2ab751.394028601518815439175.jpg"
        avatar_alt="Jilly's profile picture"
      />
      <Comment
        username="Silly"
        date="10/10/2023"
        message="Rajah, Rajah. Get choke waves this weekend. I'll see ya out there!"
        avatar_src="https://icon2.cleanpng.com/20180216/pww/kisspng-user-male-icon-business-user-cliparts-5a8748cf2ab751.394028601518815439175.jpg"
        avatar_alt="Silly's profile picture"
      />
    </div>
  </React.StrictMode>
);
