import React from 'react';

export default function Comment(props) {
  return (
    <div className="comment_container">
      <div className="comment_header">
        <div className="userInfo">
          <div className="avatar">
            <img className="avatar_img" src={props.avatar_src} alt={props.avatar_alt}/>
          </div>
          <div className="username">{props.username}</div>
        </div>
        <div className="date">{props.date}</div>
      </div>
      <div className="message">{props.message}</div>
    </div>
  );
}
