import React from 'react';
import { Routes, Route, Outlet, Link } from 'react-router-dom';
import { useRef, useState } from 'react';
import './index.css';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid'; // a plugin!
import interactionPlugin from '@fullcalendar/interaction';
import { v4 as uuid } from 'uuid';
import FullCalendar from '@fullcalendar/react';
import daygridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { useState } from 'react';
import { v4 as uuid } from 'uuid';

export default function Scheduler({ events, setEvents }) {
  const calendarRef = useRef(null);
  const [fullName, setFullname] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState('Skid Row Learning Center');
  const [startTime, setStartTime] = useState('2:30 PM');
  const [endTime, setEndTime] = useState('5:30 PM');
  const [isWeeklySchedule, setIsWeeklySchedule] = useState(false);
  const [canDrive, setCanDrive] = useState(false);
  const [dayInfo, setDayInfo] = useState(false);

  function handleSelect(info) {
    setDayInfo(info);
  }

  function handleSubmit(e) {
    if (dayInfo == false) {
      alert('Please Select a Day first');
      e.preventDefault();
    } else {
      e.preventDefault();
      const { start, end } = dayInfo;

      console.log(startTime);
      console.log(endTime);
      setEvents([
        ...events,
        {
          start,
          title: fullName + ' ' + startTime + ' - ' + endTime,
          allDay: true,
          displayEventTime: false,
          id: uuid(),
        },
      ]);
      console.log(events);
    }
  }

  function handleChange(e, value) {
    if (e.currentTarget.id == 'fullName') {
      setFullname(e.currentTarget.value);
    } else if (e.currentTarget.id == 'email') {
      setEmail(e.currentTarget.value);
    }
  }

  return (
    <div id="schedule_overall_container">
      <div id="schedule_title">
        <h1>Schedule a Ride to the Center</h1>
      </div>
      <div id="schedule_container">
        <div class="calendar">
          <FullCalendar
            ref={calendarRef}
            plugins={[daygridPlugin, interactionPlugin]}
            initialView="dayGridWeek"
            weekends={false}
            height="500px"
            headerToolbar={{
              left: 'title',
              center: '',
              right: 'prev,next',
            }}
            editable
            selectable
            select={(info) => {
              handleSelect(info);
            }}
            events={events}
          />
        </div>

        <div class="form">
          <form id="ScheduleForm" onSubmit={handleSubmit}>
            <div class="form-group">
              <label for="fullName">
                Full Name: <span></span>
              </label>
              <input
                class="scheduler_text"
                placeholder="Johny AppleSeed"
                id="fullName"
                onChange={(e) => {
                  handleChange(e);
                }}
                value={fullName}
              />
            </div>

            <div class="form-group">
              <label for="email">
                Email: <span></span>
              </label>
              <input
                class="scheduler_text"
                placeholder="JohnyAppleSeed@gmail.com"
                id="email"
                onChange={(e) => {
                  handleChange(e);
                }}
                value={email}
              />
            </div>

            <div class="form-group">
              <label for="location">Location:</label>
              <select
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                defaultValue={location}
              >
                <option value="">Select a location</option>
                <option value="Skid Row Learning Center">
                  Skid Row Learning Center
                </option>
                <option value="Online">Online</option>
              </select>
            </div>

            <div class="form-group">
              <div class="time-select">
                <label for="startTime">Start Time:</label>
                <select
                  id="startTime"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  defaultValue={startTime}
                >
                  <option>2:30 PM</option>
                  <option>3:00 PM</option>
                  <option>3:30 PM</option>
                  <option>4:00 PM</option>
                  <option>4:30 PM</option>
                  <option>5:00 PM</option>
                  <option>5:30 PM</option>
                </select>
              </div>

              <div class="time-select">
                <label for="endTime">End Time:</label>
                <select
                  id="endTime"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  defaultValue={endTime}
                >
                  <option>2:30 PM</option>
                  <option>3:00 PM</option>
                  <option>3:30 PM</option>
                  <option>4:00 PM</option>
                  <option>4:30 PM</option>
                  <option>5:00 PM</option>
                  <option>5:30 PM</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label>
                Can you drive?
                <input
                  type="checkbox"
                  checked={canDrive}
                  onChange={(e) => setCanDrive(e.target.checked)}
                />
              </label>
            </div>

            <div class="form-group">
              <label>
                Is this your weekly schedule?
                <input
                  type="checkbox"
                  checked={isWeeklySchedule}
                  onChange={(e) => setIsWeeklySchedule(e.target.checked)}
                />
              </label>
            </div>

            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
    </div>
  );
}
