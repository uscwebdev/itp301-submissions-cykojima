import React, { useState } from 'react';
import './index.css';

export default function ContactForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    if (e.currentTarget.id == 'contact_name_input') {
      setName(e.currentTarget.value);
    } else if (e.currentTarget.id == 'contact_email_input') {
      setEmail(e.currentTarget.value);
    } else if (e.currentTarget.id == 'contact_message_area') {
      setMessage(e.currentTarget.value);
    }
  };

  const handleSubmit = (e) => {
    console.log(name);
    console.log(email);
    console.log(message);
    alert('form submitted');
    e.preventDefault();
  };

  return (
    <div className="contact-form">
      <form onSubmit={handleSubmit}>
        <div className="form-group" id="contact_name">
          <label id="contact_name_label" htmlFor="name">
            Name:
          </label>
          <input
            id="contact_name_input"
            class="contact_text"
            name="name"
            value={name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group" id="contact_email">
          <label id="contact_email_label" htmlFor="email">
            Email:
          </label>
          <input
            id="contact_email_input"
            class="contact_text"
            name="email"
            value={email}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group" id="contact_message">
          <label id="contact_message_label" htmlFor="message">
            Message:
          </label>
          <textarea
            id="contact_message_area"
            name="message"
            value={message}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="submit-button">
          Submit
        </button>
      </form>
    </div>
  );
}
