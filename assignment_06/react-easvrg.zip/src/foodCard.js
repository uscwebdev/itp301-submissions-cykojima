import React from 'react';

export default function Comment(props) {
  return (
    <div className="item_column">
      <div className="food_card">
        <img className="foods" src={props.src} alt={props.alt} />
        <h2>{props.label}</h2>
      </div>
    </div>
  );
}
