import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import FoodCard from './foodCard.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="container">
      <div id="header">
        <h1>Broke Da Mouf Shopping Cart</h1>
      </div>
      <div id="row2" className="centered">
        <div className="centered" id="items">
          <FoodCard
            src="https://www.baconismagic.ca/wp-content/uploads/2020/07/poke-recipe.jpg"
            alt="poke"
            label="Poke: 15$"
          />
          <FoodCard
            src="https://www.polynesia.com/blog/wp-content/uploads/2016/10/laulau1-1.jpg"
            alt="lau lau"
            label="Lau Lau: 13$"
          />
          <FoodCard
            src="https://onohawaiianrecipes.com/wp-content/uploads/2020/07/Chicken-Long-Rice_683x1024.jpg"
            alt="chicken long rice"
            label="Chicken Long Rice: 14$"
          />
          <FoodCard
            src="https://onolicioushawaii.com/wp-content/uploads/2019/07/Kalua-Pig-20.jpg"
            alt="kalua pig"
            label="Kalua Pig: 12$"
          />
        </div>
        <div className="clear"></div>
      </div>
      <div id="row3">
        <div className="left_column">
          <h2 id="subtotal">Cart Subtotal: $0</h2>
        </div>
        <div className="right_column">
          <h2 id="Total" Funds>
            Funds: $0
          </h2>
          <div className="fund_button" id="fund_money_sign">
            <h3>$</h3>
          </div>
          <div className="fund_button">
            <input type="text" id="add_funds_box" />
          </div>
          <div className="fund_button" id="fund_add">
            <h3>Add funds</h3>
          </div>
        </div>
        <div className="clear"></div>
      </div>
      <div id="footer">
        <h2 id="footer_txt">by Conner Kojima</h2>
      </div>
    </div>
  </React.StrictMode>
);
