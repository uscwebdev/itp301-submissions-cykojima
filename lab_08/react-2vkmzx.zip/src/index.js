import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import FoodCards from './foodCard.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="container">
      <div id="header">
        <h1>Broke Da Mouf Shopping Cart</h1>
      </div>
      <FoodCards />
      <div id="footer">
        <h2 id="footer_txt">by Conner Kojima</h2>
      </div>
    </div>
  </React.StrictMode>
);
