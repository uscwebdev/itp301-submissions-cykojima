import React from 'react';
import { useState } from 'react';

export default function FoodCards(props) {
  const [subtotal, setSubtotal] = useState(0);

  function addSubtotal(price) {
    setSubtotal(subtotal + price);
  }
  function minusSubtotal(price, count) {
    setSubtotal(subtotal - price);
  }

  return (
    <div>
      <div id="row2" className="centered">
        <div className="centered" id="items">
          <FoodCard
            src="https://www.baconismagic.ca/wp-content/uploads/2020/07/poke-recipe.jpg"
            alt="poke"
            label="Poke: 15$"
            addEventHandler={addSubtotal}
            minusEventHandler={minusSubtotal}
            price="15"
          />
          <FoodCard
            src="https://foodland.com/wp-content/uploads/2023/04/LauLau.DSC_7415-600x453.jpg"
            alt="lau lau"
            label="Lau Lau: 13$"
            addEventHandler={addSubtotal}
            minusEventHandler={minusSubtotal}
            price="13"
          />
          <FoodCard
            src="https://onohawaiianrecipes.com/wp-content/uploads/2020/07/Chicken-Long-Rice_683x1024.jpg"
            alt="chicken long rice"
            label="Chicken Long Rice: 14$"
            addEventHandler={addSubtotal}
            minusEventHandler={minusSubtotal}
            price="14"
          />
          <FoodCard
            src="https://onolicioushawaii.com/wp-content/uploads/2019/07/Kalua-Pig-20.jpg"
            alt="kalua pig"
            label="Kalua Pig: 12$"
            addEventHandler={addSubtotal}
            minusEventHandler={minusSubtotal}
            price="12"
          />
        </div>
        <div className="clear"></div>
      </div>
      <div id="row3">
        <div className="left_column">
          <h2 id="subtotal">Cart Subtotal: ${subtotal}</h2>
        </div>
        <div className="right_column">
          <h2 id="Total" Funds>
            Funds: $0
          </h2>
          <div className="fund_button" id="fund_money_sign">
            <h3>$</h3>
          </div>
          <div className="fund_button">
            <input type="text" id="add_funds_box" />
          </div>
          <div className="fund_button" id="fund_add">
            <h3>Add funds</h3>
          </div>
        </div>
        <div className="clear"></div>
      </div>
    </div>
  );
}
export function FoodCard(props) {
  const [count, setCount] = useState(0);

  function handleMinusClick() {
    if (count > 0) {
      setCount(count - 1);
      props.minusEventHandler(parseInt(props.price));
    } else {
      console.log('cannot let count go below 0 ');
    }
  }
  function handlePlusClick() {
    setCount(count + 1);
    props.addEventHandler(parseInt(props.price));
  }

  return (
    <div className="item_column">
      <div className="food_card">
        <img className="foods" src={props.src} alt={props.alt} />
        <h2>{props.label}</h2>
        <div className="counter_row">
          <div className="button_row">
            <button
              className="float_right"
              onClick={() => {
                handlePlusClick();
              }}
            >
              +
            </button>
            <h3 className="float_right">{count}</h3>
            <button
              className="float_right"
              onClick={() => {
                handleMinusClick();
              }}
            >
              -
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
