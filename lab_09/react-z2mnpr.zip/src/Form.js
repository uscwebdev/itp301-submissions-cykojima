import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [fullname, setFullname] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comments, setComments] = useState('');
  const [acceptterms, setAcceptterms] = useState(false);
  const [numchars, setNumchars] = useState(0);

  function handleChange(e, value) {
    console.log(e.currentTarget.value);
    if (e.currentTarget.id == 'fullName') {
      setFullname(e.currentTarget.value);
    } else if (e.currentTarget.id == 'password') {
      setPassword(e.currentTarget.value);
    } else if (e.currentTarget.id == 'password2') {
      setPassword2(e.currentTarget.value);
    } else if (e.currentTarget.id == 'email') {
      setEmail(e.currentTarget.value);
    } else if (e.currentTarget.id == 'phone') {
      setPhone(e.currentTarget.value);
    } else if (e.currentTarget.id == 'comments') {
      setComments(e.currentTarget.value);
      setNumchars(e.currentTarget.value.length);
    } else if (e.currentTarget.id == 'acceptterms') {
      setAcceptterms(!acceptterms);
      console.log(acceptterms);
    }
  }

  function handleSubmit(e) {
    var foundError = false;

    // fullname
    if (fullname.length == 0) {
      // fullname is empty.
      foundError = true;
      alert('Name cannot be empty.');
    } else if (fullname.indexOf(' ') == -1) {
      // full name contains no spaces
      foundError = true;
      alert('You must provide a full name.');
    }

    if (password.length == 0) {
      foundError = true;
      alert('password cannot be empty.');
    } else if (password.length < 5) {
      foundError = true;
      alert('Password must contain at least 5 characters.');
    } else if (
      password == password.toLowerCase() ||
      password == password.toUpperCase()
    ) {
      foundError = true;
      alert('Password must contain uppercase and lowercase characters.');
    }

    if (password != password2) {
      foundError = true;
      alert('Passwords do not match.');
    }

    // Class standing validation.
    if (email == '' && phone == '') {
      foundError = true;
      alert('You must provide either email or phone.');
    }

    if (numchars > 100) {
      foundError = true;
      alert('Comments cannot exceed 100 characters.');
    }

    if (!acceptterms) {
      foundError = true;
      alert('You must accept Terms & Conditions.');
    }

    if (foundError == true) {
      // error was found
      e.preventDefault();
    } else {
      // no errors were found so submit form
      alert('Registration Successful');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="fullName"
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={fullname}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={password}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password2"
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={password2}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      onChange={(e) => {
                        handleChange(e);
                      }}
                      value={email}
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      onChange={(e) => {
                        handleChange(e);
                      }}
                      value={phone}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comments"
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={comments}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {numchars} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="acceptterms"
                    onChange={(e) => {
                      handleChange(e);
                    }}
                    checked={acceptterms}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
