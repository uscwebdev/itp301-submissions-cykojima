import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function MovieSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [numResults, setNumResults] = useState(0);
  const [results, setResults] = useState([]);

  function handleFormSubmission(e) {
    e.preventDefault();

    if (searchTerm != '') {
      var key = '7d88fe4207016fff8dde45a52f3d7368';
      var requestUrl =
        'https://api.themoviedb.org/3/search/movie?api_key=' +
        key +
        '&query=' +
        searchTerm;

      //https://api.themoviedb.org/3/search/movie?api_key=API_KEY&query=SEARCH_TERM

      $.ajax({
        url: requestUrl,
        dataType: 'json',
        success: function (data) {
          console.log(data);
          setResults(data.results);
          console.log(data.results);

          setNumResults(data.results.length);
          console.log(numResults);
          // setResults(data.results);
        },
        error: function (error) {
          console.log(error);
        },
      });

      setSearchTerm('');
    }
  }

  return (
    <div className="container">
      <div className="row">
        <h1 className="col-12 mt-4">Movie Search</h1>
      </div>

      <div className="row">
        <form
          className="col-12"
          id="search-form"
          onSubmit={handleFormSubmission}
        >
          <div className="form-row">
            <div className="col-12 mt-4 col-sm-6 col-md-4 col-lg-3">
              <label htmlFor="search-term" className="sr-only">
                Search:
              </label>

              <input
                type="text"
                id="search-term"
                className="form-control"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.currentTarget.value)}
              />
            </div>
            <div className="col-12 mt-4 col-sm-auto">
              <button type="submit" className="btn btn-primary btn-block">
                Search
              </button>
            </div>
          </div>
        </form>
      </div>

      <div className="row">
        <div className="col-12 mt-4 mb-4">
          Showing{' '}
          <span id="num-results" className="font-weight-bold">
            {numResults}
          </span>{' '}
          of{' '}
          <span id="num-total" className="font-weight-bold">
            {numResults}
          </span>{' '}
          result(s).
        </div>
      </div>

      <div id="movie-container" className="row">
        {results.map((elt) => {
          console.log(elt);

          return (
            <div className="text-center my-3 col-6 col-sm-4 col-md-3 col-lg-2">
              <img
                alt={elt.original_title}
                src={'http://image.tmdb.org/t/p/w500' + elt.poster_path}
              />
              <h5>{elt.original_title}</h5>
              <div>{elt.release_date}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
