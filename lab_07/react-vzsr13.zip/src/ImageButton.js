import React from 'react';
import { useState } from 'react';

export default function ImageButtons() {
  const [src, setSrc] = useState(
    'https://upload.wikimedia.org/wikipedia/commons/4/4e/Mavericks_Surf_Contest_2010b.jpg'
  );
  const [alt, setAlt] = useState('surfing');
  const [caption, setCaption] = useState('surfing');

  function handleClick(newSrc, newAlt, newCaption) {
    console.log('changing the image');
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div id="container">
      <div id="row1">
        <h1>My Hobbies</h1>
      </div>
      <div id="row2" className="centered">
        <div className="centered" id="test">
          <div className="column">
            <button
              className="centered"
              onClick={() => {
                handleClick(
                  'https://upload.wikimedia.org/wikipedia/commons/4/4e/Mavericks_Surf_Contest_2010b.jpg',
                  'surfing',
                  'surfing'
                );
              }}
            >
              <img
                className="hobbies"
                src="https://upload.wikimedia.org/wikipedia/commons/4/4e/Mavericks_Surf_Contest_2010b.jpg"
                alt="surfing"
              />
            </button>
          </div>
          <div className="column">
            <button
              className="centered"
              onClick={() => {
                handleClick(
                  'https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/Sushi_chef_Masayoshi_Kazato_02.JPG/640px-Sushi_chef_Masayoshi_Kazato_02.JPG',
                  'cooking',
                  'cooking'
                );
              }}
            >
              <img
                className="hobbies"
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/Sushi_chef_Masayoshi_Kazato_02.JPG/640px-Sushi_chef_Masayoshi_Kazato_02.JPG"
                alt="cooking"
              />
            </button>
          </div>
          <div className="column">
            <button
              className="centered"
              onClick={() => {
                handleClick(
                  'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Hiking_to_the_Ice_Lakes._San_Juan_National_Forest%2C_Colorado.jpg/1200px-Hiking_to_the_Ice_Lakes._San_Juan_National_Forest%2C_Colorado.jpg',
                  'hiking',
                  'hiking'
                );
              }}
            >
              <img
                className="hobbies"
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Hiking_to_the_Ice_Lakes._San_Juan_National_Forest%2C_Colorado.jpg/1200px-Hiking_to_the_Ice_Lakes._San_Juan_National_Forest%2C_Colorado.jpg"
                alt="hiking"
              />
            </button>
          </div>
          <div className="column">
            <button
              className="centered"
              onClick={() => {
                handleClick(
                  'https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Roundnet_Serve.jpg/220px-Roundnet_Serve.jpg',
                  'spikeball',
                  'spikeball'
                );
              }}
            >
              <img
                className="hobbies"
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Roundnet_Serve.jpg/220px-Roundnet_Serve.jpg"
                alt="spikeball"
              />
            </button>
          </div>
          <div className="column">
            <button
              className="centered"
              onClick={() => {
                handleClick(
                  'https://upload.wikimedia.org/wikipedia/commons/a/a7/40._Schwimmzonen-_und_Mastersmeeting_Enns_2017_100m_Brust_Herren_USC_Traun-9897.jpg',
                  'swimming',
                  'swimming'
                );
              }}
            >
              <img
                className="hobbies"
                src="https://upload.wikimedia.org/wikipedia/commons/a/a7/40._Schwimmzonen-_und_Mastersmeeting_Enns_2017_100m_Brust_Herren_USC_Traun-9897.jpg"
                alt="swimming"
              />
            </button>
          </div>
          <div className="clear"></div>
        </div>
      </div>
      <div id="row3">
        <div className="centered">
          <img id="main_image" src={src} alt={alt} />
          <h2 id="main_image_caption">{caption}</h2>
        </div>
      </div>
    </div>
  );
}
