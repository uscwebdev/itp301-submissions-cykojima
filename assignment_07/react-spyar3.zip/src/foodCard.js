import React from 'react';
import { useState } from 'react';

export default function Comment(props) {
  const [count, setCount] = useState(0);

  function handleMinusClick() {
    if (count > 0) {
      setCount(count - 1);
    } else {
      console.log('cannot let count go below 0 ');
    }
  }
  function handlePlusClick() {
    setCount(count + 1);
  }

  return (
    <div className="item_column">
      <div className="food_card">
        <img className="foods" src={props.src} alt={props.alt} />
        <h2>{props.label}</h2>
        <div className="counter_row">
          <div className="button_row">
            <button
              className="float_right"
              onClick={() => {
                handlePlusClick();
              }}
            >
              +
            </button>
            <h3 className="float_right">{count}</h3>
            <button
              className="float_right"
              onClick={() => {
                handleMinusClick();
              }}
            >
              -
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
